Open combined_warsaw_map_full.html in your browser. 
Markers 1-6 include cleaned memoir text. Images from the Rotstein PDF have been embedded in the HTML and are also stored in assets/.
Videos are linked to streaming search results (YouTube) and open in a new tab.
All external streaming content is free to view but requires an internet connection.
